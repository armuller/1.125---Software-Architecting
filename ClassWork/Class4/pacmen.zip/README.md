# pacmen
Factory for making pacmen
You are given a starter.html code.
When button "make one" is pressed you need to complete the code 
to position the new pacman image and add it to the "game" div. It is then added to the array of pacmen, which keeps track of the position and velocity of each pacman.
You also need to make each pacman bounce off any wall it hits. 
Start by getting at least one pacman positioned and viewable. 

<img src="PacMan1.png">
